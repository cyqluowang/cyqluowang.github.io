package com.tuyenmonkey.mkloader.type;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.util.Log;

import com.tuyenmonkey.mkloader.model.Circle;

/**
 * Created by Tuyen Nguyen on 2/10/17.
 */

public class ClassicSpinner extends LoaderView {
  private Circle[] circles;
  private int circlesSize;

  public ClassicSpinner() {
    circlesSize = 8;//设定几个圆点
  }

  @Override public void initializeObjects() {
    final float size = Math.min(width, height);
    final float circleRadius = size / 10.0f;//10 应该是调试找的一个比较合适的值

    circles = new Circle[circlesSize];//创建出8个圆点

    for (int i = 0; i < circlesSize; i++) {
      circles[i] = new Circle();
      circles[i].setCenter(center.x, circleRadius);
      circles[i].setColor(color);
      circles[i].setAlpha(126);
      circles[i].setRadius(circleRadius);
    }
  }

  @Override public void setUpAnimation() {
    for (int i = 0; i < circlesSize; i++) {
      final int index = i;
        //动画属性 从126 到 255 到 126 变化  渐变alpha值
      ValueAnimator fadeAnimator = ValueAnimator.ofInt(126, 255, 126);
      fadeAnimator.setRepeatCount(ValueAnimator.INFINITE);
      fadeAnimator.setDuration(1000);
      fadeAnimator.setStartDelay(index * 120);//后面的点比前一个点慢一点变化，就会有一个视觉差
      fadeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
        @Override public void onAnimationUpdate(ValueAnimator animation) {
          circles[index].setAlpha((int)animation.getAnimatedValue());
          invalidateListener.reDraw();//调用重绘
        }
      });

      fadeAnimator.start();//开始动画
    }
  }

  @Override public void draw(Canvas canvas) {
      for (int i = 0; i < circlesSize; i++) {
          canvas.save();//保存画布现场
          canvas.rotate(45 * i, center.x, center.y);//旋转画布，每个点相聚45度，8个点  360度
          circles[i].draw(canvas);//画点
          canvas.restore();//恢复画布，下一次就是旋转90度可以
      }

  }
}
