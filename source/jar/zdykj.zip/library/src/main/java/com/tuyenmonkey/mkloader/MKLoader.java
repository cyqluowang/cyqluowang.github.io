package com.tuyenmonkey.mkloader;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import com.tuyenmonkey.mkloader.callback.InvalidateListener;
import com.tuyenmonkey.mkloader.type.LoaderView;
import com.tuyenmonkey.mkloader.util.LoaderGenerator;

/**
 * 自定义等待的无限循环条
 * 本质：
 * 1、用一系列画笔Paint，分别绘制集合图像(圆点，线)
 * 2、修改画笔的属性(颜色，透明度)
 * 3、重新调用onDraw，重绘试图。
 *
 *
 * 项目构思：
 * 1、抽象出一个类(小圆点)，包括 画笔 位置（Circle）
 * 2、抽象出整个进度条(8个圆点)  初始化的8个对象的方法，设置动画的方法，真正绘制的方法(ClassicSpinner)
 * 3、MKLoader extends View 在view初始化的时候，初始化进度条
 * 4、implements InvalidateListener  实现第二步的时候的接口，让其可以方便重绘试图
 *
 *
 */

public class MKLoader extends View implements InvalidateListener {
  private LoaderView loaderView;

  public MKLoader(Context context) {
    super(context);
    initialize(context, null, 0);
  }

  public MKLoader(Context context, AttributeSet attrs) {
    super(context, attrs);
    initialize(context, attrs, 0);
  }

  public MKLoader(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initialize(context, attrs, defStyleAttr);
  }

  private void initialize(Context context, AttributeSet attrs, int defStyleAttr) {
    TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.MKLoader);

    String loaderType = typedArray.getString(R.styleable.MKLoader_mk_type);
    if (loaderType == null) loaderType = "ClassicSpinner";
    loaderView = LoaderGenerator.generateLoaderView(loaderType);//根据type来选择，实际就是new
    loaderView.setColor(typedArray.getColor(R.styleable.MKLoader_mk_color, Color.parseColor("#ffffff")));//设置颜色
    loaderView.setInvalidateListener(this);//监听，实现redraw方法
    //程序在运行时维护了一个 TypedArray的池，
    // 程序调用时，会向该池中请求一个实例，用完之后，
    // 调用 recycle() 方法来释放该实例，从而使其可被其他模块复用。
    typedArray.recycle();
  }

  @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
      //默认宽高设置
    final int measuredWidth = resolveSize(loaderView.getDesiredWidth(), widthMeasureSpec);
    final int measuredHeight = resolveSize(loaderView.getDesiredHeight(), heightMeasureSpec);
    //设置得到的宽高
    setMeasuredDimension(measuredWidth, measuredHeight);
  }

  @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
    super.onLayout(changed, left, top, right, bottom);
      //设置对象的宽高（得到控件的宽高）
    loaderView.setSize(getWidth(), getHeight());
      //初始化对象属性，new 画笔等操作
    loaderView.initializeObjects();
      //开始动画
    loaderView.setUpAnimation();
  }

  @Override protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
      //真正的画图
    loaderView.draw(canvas);
  }

  @Override public void reDraw() {
      //手动调用onDraw，重绘（因为有透明度修改，所以要设置了新的透明度就要调用重绘，这样才会有动画效果）
    invalidate();
  }
}
