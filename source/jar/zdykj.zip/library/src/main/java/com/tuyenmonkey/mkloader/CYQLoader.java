package com.tuyenmonkey.mkloader;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import com.tuyenmonkey.mkloader.model.Circle;

/**
 * Created by cyq on 2017/2/24.
 */

public class CYQLoader extends View {

    private Circle[] circles;
    private int circlesSize = 8;
    protected Paint[] paint;

    public CYQLoader(Context context) {
        super(context);
//        initialize(context, null, 0);
    }

    public CYQLoader(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context, attrs, 0);
    }

    public CYQLoader(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
//        initialize(context, attrs, defStyleAttr);
    }

    private void initialize(Context context, AttributeSet attrs, int defStyleAttr) {
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.MKLoader);
        String loaderType = typedArray.getString(R.styleable.MKLoader_mk_type);
        if (loaderType == null) loaderType = "ClassicSpinner";


        typedArray.recycle();

        circles = new Circle[circlesSize];
        paint = new Paint[circlesSize];

    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        final int measuredWidth = resolveSize(150, widthMeasureSpec);
        final int measuredHeight = resolveSize(150, heightMeasureSpec);

        setMeasuredDimension(measuredWidth, measuredHeight);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        for (int i = 0; i < circlesSize; i++) {
            circles[i] = new Circle();
            paint[i] = new Paint();
            paint[i].setColor(Color.parseColor("#ffffff"));
            paint[i].setAlpha(126);
            circles[i].setCenter(150/2, 15);
            circles[i].setColor(Color.parseColor("#ffffff"));
            circles[i].setAlpha(126);
            circles[i].setRadius(15);
        }


        for (int i = 0; i < circlesSize; i++) {
            final int index = i;

            ValueAnimator fadeAnimator = ValueAnimator.ofInt(126, 255, 126);
            fadeAnimator.setRepeatCount(ValueAnimator.INFINITE);
            fadeAnimator.setDuration(1000);
            fadeAnimator.setStartDelay(index * 120);
            fadeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator animation) {
                    paint[index].setAlpha((int)animation.getAnimatedValue());
                    invalidate();
                }
            });

            fadeAnimator.start();
        }

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (int i = 0; i < circlesSize; i++) {
            canvas.save();
            canvas.rotate(45 * i, 150/2, 150/2);
//            circles[i].draw(canvas);

            canvas.drawCircle(150/2, 15, 15, paint[i]);

            canvas.restore();
        }

    }
}
