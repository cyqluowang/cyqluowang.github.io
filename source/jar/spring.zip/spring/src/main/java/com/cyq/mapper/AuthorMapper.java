package com.cyq.mapper;

import com.cyq.bean.Author;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * Created by cyq on 2017/2/5.
 */
//@Component
//@Repository
@Mapper
public interface AuthorMapper {
    Author selectAuthorById(int id);
}
