package com.cyq;


import com.cyq.bean.Author;
import com.cyq.mapper.AuthorMapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.*;

@RestController
@SpringBootApplication
public class MyApplication {

    @Autowired
    private AuthorMapper aaa;

    @RequestMapping("/")
    @ResponseBody
    public String home(@RequestParam Integer cid) {
       Author a= aaa.selectAuthorById(10);
        return "Hello World!"+cid+a.getTitle();
    }


    public static void main(String[] args) throws Exception {
        SpringApplication.run(MyApplication.class, args);
    }



}