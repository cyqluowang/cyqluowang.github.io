#!/usr/bin/python
#-*- coding: utf-8 -*-
#encoding=utf-8

import os
import os.path
import string,re,sys
import shutil
import sys

podspec_dir = "./" + sys.argv[1] + ".podspec"

def creatFrame():
    shell = 'sh ./creatFramework.sh ' + sys.argv[1]
    output = os.system(shell)
    copyFramework(sys.argv[1]+"-"+getVersion(),sys.argv[1])
    shutil.rmtree("./" + sys.argv[1] + "-" + getVersion())


# 获取version
def  getVersion():
    f = open(podspec_dir,'r')
    for lineStr in f.readlines():
        lineStr = lineStr.replace("\n","")
        if lineStr.find("s.version")>-1:
            versionStr = lineStr.replace("s.version","")
            versionStr = versionStr.replace(" ","")
            versionStr = versionStr.replace("'","")
            versionStr = versionStr.replace("\"","")
            versionStr = versionStr.replace("=","")
            return versionStr

def copyFramework(orginDirName,subspecName):
    real_des_Dir = './' + 'Framework/' + getVersion() + '/'
    if os.path.exists(os.path.join(real_des_Dir,subspecName)):
        shutil.rmtree(os.path.join(real_des_Dir,subspecName))
    shutil.copytree(os.path.join("./",orginDirName),os.path.join(real_des_Dir,subspecName))

if __name__ == '__main__':
    creatFrame()
